import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'auth_service.dart';
import 'firestore_service.dart';

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  final FirestoreService firestoreService = FirestoreService();
  final TextEditingController textController = TextEditingController();

  // Fungsi Dialog untuk Tambah/Edit (Tahap 5 CRUD)
  void openNoteBox({String? docID, String? existingText}) {
    if (existingText != null) textController.text = existingText;
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text(docID == null ? "Tambah Data" : "Edit Data"),
        content: TextField(controller: textController),
        actions: [
          ElevatedButton(
            onPressed: () async {
              if (docID == null) {
                await firestoreService.addNote(textController.text);
              } else {
                await firestoreService.updateNote(docID, textController.text);
              }
              textController.clear();
              Navigator.pop(context);
            },
            child: const Text("Simpan"),
          )
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final user = FirebaseAuth.instance.currentUser; // Mengambil data user login

    return Scaffold(
      appBar: AppBar(
        title: const Text("Dashboard CRUD"),
        actions: [
          // Tombol Logout sesuai modul hal 130
          IconButton(
            icon: const Icon(Icons.logout),
            onPressed: () async => await AuthService().logout(),
          ),
        ],
      ),
      body: Column(
        children: [
          // Tampilkan Email User sesuai modul hal 134
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: Text("Login sebagai: ${user?.email}"),
          ),

          // Tampilan List Data dari Firestore
          Expanded(
            child: StreamBuilder<QuerySnapshot>(
              stream: firestoreService.getNotesStream(),
              builder: (context, snapshot) {
                if (snapshot.hasData) {
                  return ListView.builder(
                    itemCount: snapshot.data!.docs.length,
                    itemBuilder: (context, index) {
                      var doc = snapshot.data!.docs[index];
                      return Card(
                        child: ListTile(
                          title: Text(doc['content']),
                          trailing: Row(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              IconButton(icon: const Icon(Icons.edit), onPressed: () => openNoteBox(docID: doc.id, existingText: doc['content'])),
                              IconButton(icon: const Icon(Icons.delete), onPressed: () => firestoreService.deleteNote(doc.id)),
                            ],
                          ),
                        ),
                      );
                    },
                  );
                }
                return const Center(child: CircularProgressIndicator());
              },
            ),
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () => openNoteBox(),
        child: const Icon(Icons.add),
      ),
    );
  }
}