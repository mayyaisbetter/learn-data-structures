import 'package:firebase_auth/firebase_auth.dart';

class AuthService {
  final FirebaseAuth _auth = FirebaseAuth.instance;

  // status login
  Stream<User?> get userChanges => _auth.authStateChanges();

  // register
  Future<User?> register(String email, String password) async {
    try {
      UserCredential userCredential = await _auth.createUserWithEmailAndPassword(
        email: email,
        password: password,
      );
      return userCredential.user; // Mengembalikan data user jika sukses
    } catch (e) {
      print('Error register: $e');
      return null;
    }
  }

  // login
  Future<User?> login(String email, String password) async {
    try {
      // Proses login ke Firebase
      UserCredential userCredential = await _auth.signInWithEmailAndPassword(
        email: email,
        password: password,
      );
      return userCredential.user;
    } catch (e) {
      print('Error login: $e');
      return null;
    }
  }

  // logout
  Future<void> logout() async {
    await _auth.signOut();
  }
}