dart pub add firebase_auth
npm install -g firebase-tools
firebase --version
firebase login
flutterfire --version
flutterfire configure
dart pub add firebase_core
dart pub add cloud_firestore

dart pub add cloud_firestore