import 'package:cloud_firestore/cloud_firestore.dart';

class FirestoreService {
  final CollectionReference notes = FirebaseFirestore.instance.collection('notes');

  Future<void> addNote(String note) {
    return notes.add({'content': note, 'timestamp': Timestamp.now()});
  }

  Stream<QuerySnapshot> getNotesStream() {
    return notes.orderBy('timestamp', descending: true).snapshots();
  }

  Future<void> updateNote(String docID, String newContent) {
    return notes.doc(docID).update({'content': newContent, 'timestamp': Timestamp.now()});
  }

  Future<void> deleteNote(String docID) {
    return notes.doc(docID).delete();
  }
}