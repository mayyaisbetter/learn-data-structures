import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'auth_service.dart'; // Import file AuthService yang tadi dibuat
import 'login_page.dart';   // Import halaman Login Anda
import 'home_page.dart';    // Import halaman Home Anda

class AuthWrapper extends StatelessWidget {
  const AuthWrapper({super.key});

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<User?>(
      // Mengambil aliran data status login dari AuthService
      stream: AuthService().userChanges,
      builder: (context, snapshot) {
        // 1. Jika koneksi masih loading (sedang mengecek status di Firebase)
        if (snapshot.connectionState == ConnectionState.waiting) {
          return const Scaffold(
            body: Center(
              child: CircularProgressIndicator(), // Loading indicator
            ),
          );
        }

        // 2. Jika snapshot memiliki data (berarti User tidak null / sudah login)
        if (snapshot.hasData) {
          return const HomePage(); // Arahkan ke halaman utama
        }

        // 3. Jika data kosong (User null / belum login atau sudah logout)
        return const LoginPage(); // Arahkan ke halaman login
      },
    );
  }
}